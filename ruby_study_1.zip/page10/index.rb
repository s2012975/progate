length = 9
width = 8
puts width
puts length * width

puts "----"
# widthの値に5を足して、widthの値を変更してください
width += 5

puts width
puts length * width
