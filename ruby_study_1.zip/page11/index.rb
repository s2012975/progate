length = 9
width = 8
area = length * width

# 「面積は◯◯です」となるように出力してください
puts "面積は#{area}です"
