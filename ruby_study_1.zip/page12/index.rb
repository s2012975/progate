score = 92

# 条件式を「score > 80」とするif文をつくってください
if score > 80
  puts "よくできました"
end
