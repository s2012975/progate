score = 80

# 「score > 80」を出力してください
puts score > 80

# 「score <= 80」を出力してください
puts score <= 80

# scoreの値が80以下の場合に、「がんばりましょう」と出力してください
if score <= 80
  puts "がんばりましょう"
end
