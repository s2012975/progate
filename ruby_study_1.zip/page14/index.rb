score = 100

# scoreの値が100の場合、「満点です」と出力してください
if score == 100
  puts "満点です"
end
# scoreの値が100でない場合、「満点ではありません」と出力してください
if score != 100
  puts "満点ではありません"
end
