# 「こんにちは、Ruby」と出力してください
puts "こんにちは、Ruby"

# 以下の行をコメントにしてください
# puts "Hello Ruby"
