text = "プログラミングを学ぼう"

# 文字列「Progateで」と変数textを連結して、出力してください
puts "Progateで" + text

length = 8
width = 9

# 変数lengthと変数widthを掛けて出力してください
puts length * width
