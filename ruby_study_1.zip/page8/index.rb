# 変数textに「をマスターしよう」を代入してください
text = "をマスターしよう"

# 下記の文字列に変数textを連結してください
puts "HTML" + text
puts "CSS" + text
puts "Ruby" + text