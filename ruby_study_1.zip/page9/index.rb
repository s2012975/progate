length = 9
width = 8
puts width
puts length * width
puts "----"

# 変数widthの値を13に変更してください
width = 13

puts width
puts length * width
